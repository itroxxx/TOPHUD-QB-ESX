if Config.Framework == 'ESX' then
    ESX = exports['es_extended']:getSharedObject()
elseif Config.Framework == 'QBCore' then
    QBCore = exports['qb-core']:GetCoreObject()
end

RegisterServerEvent('saveHudSettings')
AddEventHandler('saveHudSettings', function(settings)
    local src = source
    -- Save the settings to the database or a file
    -- Example: MySQL.Async.execute('UPDATE users SET hud_settings = @settings WHERE identifier = @identifier', {['@settings'] = json.encode(settings), ['@identifier'] = GetPlayerIdentifier(src)})
end)

RegisterServerEvent('closeHudStyling')
AddEventHandler('closeHudStyling', function()
    local src = source
    -- Handle any additional logic needed when closing the HUD styling menu
    -- Example: MySQL.Async.execute('UPDATE users SET hud_settings_open = 0 WHERE identifier = @identifier', {['@identifier'] = GetPlayerIdentifier(src)})
end)