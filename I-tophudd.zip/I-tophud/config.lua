Config = {}

-- Framework settings
Config.Framework = 'ESX' -- Options: 'ESX', 'QBCore'